import 'dart:async';
import 'dart:math';

Future<int> computeArraySum(List<int> numbers) async {
  int delaySeconds = Random().nextInt(5) + 1;
  print("Simulating delay: $delaySeconds seconds...");

  await Future.delayed(Duration(seconds: delaySeconds));

  int sum = numbers.reduce((a, b) => a + b);
  return sum;
}

void main() async {
  List<int> values = [10, 20, 30, 40, 50];
  print("Starting sum calculation...");
  int total = await computeArraySum(values);
  print("Computed sum: $total");
}
