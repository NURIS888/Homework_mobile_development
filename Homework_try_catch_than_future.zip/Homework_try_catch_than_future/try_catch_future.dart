import 'dart:async';

class User {
  final int id;
  final String name;

  User(this.id, this.name);

  @override
  String toString() => 'User(id: $id, name: $name)';
}

class Database {
  Future<List<User>> fetchUsers() async {
    await Future.delayed(Duration(seconds: 2));
    return [
      User(1, 'Nur Islam'),
      User(2, 'Tilek'),
      User(3, 'Rasim'),
    ];
  }

  Future<User> fetchUserById(int id) async {
    final users = await fetchUsers();
    await Future.delayed(Duration(seconds: 1));
    return users.firstWhere(
      (user) => user.id == id,
      orElse: () => throw Exception('User with ID $id not found'),
    );
  }
}

Future<int> performComputation() async {
  return Future.delayed(Duration(seconds: 3), () => 42);
}

void main() async {
  final database = Database();

  database.fetchUsers().then((users) {
    print('Users retrieved successfully:');
    users.forEach((user) => print(' - $user'));
  }).catchError((e) {
    print('Error retrieving users: $e');
  }).whenComplete(() {
    print('User retrieval process completed.');
  });

  try {
    final user = await database.fetchUserById(2);
    print('User found: $user');
  } catch (e) {
    print('Error: $e');
  } finally {
    print('User lookup finished.');
  }

  print('Initiating computation...');
  performComputation().then((result) {
    print('Computation completed with result: $result');
  }).catchError((e) {
    print('Computation failed: $e');
  });

  print('Main program continues...');
}
