mixin PerformanceTracker on VehicleBase {
  void logPerformance(String message) {
    print("[Performance Log] $message");
  }

  static void displayNotice() {
    print("[Notice] Always ensure your vehicle is in optimal condition!");
  }
}

class VehicleBase {
  int maxSpeed = 0;
  int currentSpeed = 0;
}

class Car extends VehicleBase with PerformanceTracker {
  String model;

  Car(this.model, int speedLimit) {
    maxSpeed = speedLimit;
    currentSpeed = 0;
  }

  void accelerate(int increase) {
    if (currentSpeed + increase > maxSpeed) {
      logPerformance("$model cannot exceed its max speed of $maxSpeed km/h!");
    } else {
      currentSpeed += increase;
      logPerformance("$model is now moving at $currentSpeed km/h.");
    }
  }

  void brake() {
    currentSpeed = 0;
    logPerformance("$model has come to a full stop.");
  }
}

class Motorbike extends VehicleBase with PerformanceTracker {
  String brand;

  Motorbike(this.brand, int speedLimit) {
    maxSpeed = speedLimit;
    currentSpeed = 0;
  }

  void accelerate(int increase) {
    if (currentSpeed + increase > maxSpeed) {
      logPerformance("$brand cannot exceed its speed limit of $maxSpeed km/h!");
    } else {
      currentSpeed += increase;
      logPerformance("$brand is cruising at $currentSpeed km/h.");
    }
  }

  void stop() {
    currentSpeed = 0;
    logPerformance("$brand has stopped moving.");
  }
}

void main() {
  Car tesla = Car("Tesla Model S", 250);
  tesla.accelerate(100);
  tesla.accelerate(160);
  tesla.brake();

  Motorbike yamaha = Motorbike("Yamaha R1", 180);
  yamaha.accelerate(120);
  yamaha.stop();

  PerformanceTracker.displayNotice();
}